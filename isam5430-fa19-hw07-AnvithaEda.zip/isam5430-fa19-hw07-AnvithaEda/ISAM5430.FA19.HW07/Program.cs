﻿using System;

namespace ISAM5430.FA19.HW07
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
