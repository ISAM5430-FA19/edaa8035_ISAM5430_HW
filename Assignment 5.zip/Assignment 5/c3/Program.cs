﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c3
{
    class Program
    {
        static void Main(string[] args)
        {
            Money money1 = new Money(2.5);
            Money money2 = new Money(1.5);
            //money1.DecrementMoney();
            //money2.IncrementMoney();
            Console.WriteLine(money1.MoneyValue());
            Console.WriteLine(money2.MoneyValue());
            Console.WriteLine(money1);
            Console.WriteLine(money2);
        }
    }
}
