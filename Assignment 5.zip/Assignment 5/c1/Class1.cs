﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c1
{
    class Class1
    {
       static void Main(string[] args)
        {
            Student name = new Student("anvitha", "eda", "mis");
            Console.Write($"full name:{name.FullName}\n gpa:{name.GPA}\n");
        }
    }
}
