﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c1
{
    class Student
    {
        int studentNumber;
        string firstName;
        string lastName;
        decimal overallGPA;
        string classification;
        string major;
        public Student(string fn,string ln)
        {

            firstName = fn;
            lastName = ln;
        }
        public Student(string fn,string ln,string mj)
        {
            firstName = fn;
            lastName = ln;
            major = mj;
            overallGPA = 0.0m;
        }
        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                firstName = value;
            }
        }

        public string LasrtName
        {
            get
            {
                return lastName;
            }
            set
            {
                lastName = value;
            }
        }
        public string FullName
        {
            get { return $"{firstName}{lastName}"; }
        }
        public decimal GPA
        {
            get
            {
                return overallGPA;
            }
            set
            {
                overallGPA = value;
            }
        }

    }
}
