﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c5
{
    class date
    {
        private int month;
        private int day;
        private int year {get; set; }
        private int Month
        {
            get
            {
                return month;
            }
            set
            {
                if (value >= 1 && value <= 12)
                    month = value;
            }
        }
        public int Day
        {
            get {
                return day;
            }
            set
            {
                if (value >= 1 && value <= 31) day = value;
            }
        }
        public date(int m, int d, int y)
        {
            month = m;
            day = d;
            year = y;
        }
        public string DisplayDate()
        {
            //return ($"{ month}/{ day}/{ year}");
            DateTime dt = new DateTime(year, month, day);
            return dt.ToString("d");
        }
    }
}
