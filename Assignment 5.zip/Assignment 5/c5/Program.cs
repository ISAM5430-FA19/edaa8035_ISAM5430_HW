﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter month");
            int m = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter day");
            int d = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter year");
            int y = int.Parse(Console.ReadLine());
            date date = new date(m, d, y);
            Console.WriteLine("Display" + date.DisplayDate());
        }
    }
}
