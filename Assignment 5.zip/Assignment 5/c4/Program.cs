﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c4
{
    class Program
    {
        static void Main(string[] args)
        {

            parks parkname = new parks(" dog park", "Texas", "State", 7, 50, 7000, 50000m);

                Console.WriteLine(parkname);
            }
        }
    }

