﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c4
{
    class parks
    {
        String nameofpark;
        String location;
        String type;
        decimal fee;
        int noofemp;
        int noofvisitors;
        decimal budget;

        public parks(string Nameofpark,string Location,string Type,decimal Fee,int Noofemp,int Noofvisitors,decimal Budget)
        {
            _nameofpark = Nameofpark;
            _location = Location;
            _type = Type;
            _fee = Fee;
            _noofvisitors = Noofvisitors;
            _noofemp = Noofemp;
            _budget = Budget;
        }
        public string _nameofpark
        {
            get
            {
                return nameofpark;
            }
            set
            {
                nameofpark = value;
            }
        }
        public string _location
        {
            get
            {
                return location;
            }
            set
            {
                location = value;
            }
        }
        public string _type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }
        public decimal _fee
        {
            get
            {
                return fee;
            }
            set
            {
                fee = value;
            }
        }
        public int _noofvisitors
        {
            get
            {
                return noofvisitors;
            }
            set
            {
                noofvisitors = value;
            }
        }
        public int _noofemp
        {
            get
            {
                return noofemp;
            }
            set
            {
                noofemp = value;
            }
        }
        public decimal _budget
        {
            get
            {
                return budget;
            }
            set
            {
                budget = value;
            }
        }
        //a
        public string NameAndLocation
        {
            get
            {
                return $"{nameofpark} {location}";
            }
        }

        public string NameLocatioAndType {
            get
            {
                return $"{nameofpark} {location} {type}";
            }
        }
        public string costpervisitor
        {
            get
            {
                return $"${budget / noofvisitors}";
            }
        }
        public string Revenue
        {
            get
            {
                return $"${fee * noofvisitors}";
            }
        }
        public override string ToString()
        {
            return $"Name: {_nameofpark}\nLocation: {_location}\nType: {_type}\nFee: {_fee:C}\nEmployee Count: {_noofemp}\nVisitor Count: {_noofvisitors}\nRevenue: {Revenue:C}\nAnnual Budget: {_budget:C}";
        }
    }

}





