﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c2
{
    class Program
    {
        static void Main(string[] args)
        {
            MotorWay motorway = new MotorWay("Anvitha's Motorway", "highway", "blue body with convertable ", 3);
            motorway.Direction = "west";
            motorway.Toll = false;
            motorway.MaintainedBy = "anvitha";

            Console.WriteLine(motorway);
        }
    }
}
