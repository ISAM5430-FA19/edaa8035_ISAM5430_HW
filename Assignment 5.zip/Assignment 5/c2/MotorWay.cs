﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c2
{
    class MotorWay
    {
        String type;
        String name;
        String surface;
        String directions;
        int lanes;
        bool tolles;
        String maintainedby;

        public MotorWay(string _Name,string _Type,string _Surface, int _Lanes)
        {
            Name = _Name;
            Type = _Type;
            Surface = _Surface;
            Lanes = _Lanes;
        }
        public MotorWay(string _Name, string _Type, bool _Tolles)
        {
            Name = _Name;
            Type = _Type;
            Toll = _Tolles;
            
        }
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public string Type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }
        public string Direction
        {
            get
            {
                return directions;
            }
            set
            {
                directions = value;
            }
        }

        public string Surface
        {
            get
            {
                return surface;
            }
            set
            {
                surface = value;
            }
        }
        public int Lanes
        {
            get
            {
                return lanes;
            }
            set
            {
                lanes = value;
            }
        }
        public bool Toll
        {
            get
            {
                return tolles;
            }
            set
            {
                tolles = value;
            }
        }
        public string  MaintainedBy
        {
            get
            {
                return maintainedby;
            }
            set
            {
                maintainedby = value;
            }
        }

        public override string ToString()
        {
            return $"Name: {Name}\nType: {Type}\nDirection: {Direction}\nSurface: {Surface}\nLanes: {Lanes}\nToll: {Toll}\nMaintained By: {MaintainedBy}\n";
        }




    }
}
