﻿using System;

namespace ISAM5430.FA19.HW06
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
