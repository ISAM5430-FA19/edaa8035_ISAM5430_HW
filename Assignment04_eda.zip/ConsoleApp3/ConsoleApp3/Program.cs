﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            //for printing 1,2,3,4,5

            for (int i = 1; i <= 5; i++)
            {
                Console.Write(i + ",");

            }
            Console.WriteLine("\n");

            //for the three numbers in sequence and sum of all permuatation products

            int sum = 0;
            for (int k = 1; k <= 5; k++)
            {
                for (int j = 1; j <= 5; j++)
                {
                    for (int z = 1; z <= 5; z++)
                    {
                        if (k != j && j != z && z != k)
                        {
                            Console.WriteLine(k + " " + j + " " + z );
                           
                            sum = sum + k * j * z;
                            Console.WriteLine(sum);
                        }

                    }
                }
            }
            //for sum of all permutations product
            
            for(int i=1;i<=5;i++)
            {
                for(int j=1;j<=5;j++)
                {
                    if (i != j)
                    {
                        Console.WriteLine(i + " " + j);

                        sum = sum + (i * j);
                    }
                }
            }
            Console.WriteLine(sum);

            

                Console.ReadLine();
            }
        }
    }

