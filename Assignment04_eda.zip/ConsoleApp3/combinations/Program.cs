﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace combinations
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            for (int i = 1; i <= 5; i++)
            {
                for (int j = i + 1; j <= 5; j++)
                {
                    if (i != j)
                    {
                        Console.WriteLine(i + "," + j);
                        
                    }
                   sum = sum + (i * j);
                }
               
                
            }
            Console.WriteLine(sum);

            for (int i = 1; i <= 5; i++)
            {
                for (int j = i + 1; j <= 5; j++)
                {
                    for (int k = j + 1; j <= 5; j++)
                    {
                        Console.WriteLine(i + "," + j + "," + k);
                        sum = sum + (i * j * k);

                    }
                }
            }
                Console.WriteLine(sum);

            
            for(int i = 1; i <= 5; i++)
            {
                for (int j = i + 1; j <= 5; j++)
                {
                    for (int k = i + 1; j <= 5; j++)
                    {
                        for (int z = i + 1; z <= 5; z++)
                        {
                            Console.WriteLine(i + "," + j + "," + k + "," + z);
                            sum = sum + (i * j * k * z);
                        }
                    }
                }
            }
            Console.WriteLine(sum);
            
            Console.ReadLine();
        }
    }
}



