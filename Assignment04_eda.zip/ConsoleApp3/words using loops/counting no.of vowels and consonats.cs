﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace words_using_loops
{
    class Class1
    {
        static void Main(string[] args)
        {
            int Vowels = 0;
            int Consonants = 0;
            bool IsVowel;
            Console.Write("enter the word: ");
            while (true)
            {
                var keyInfo = Console.ReadKey();
                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
                if (!char.IsLetter(letter))
                {
                    break;
                }
                IsVowel = letter == 'A' || letter == 'E' || letter == 'I' || letter == 'O' || letter == 'U' || letter == 'Y';
                if (IsVowel)
                {
                    Vowels++;
                }
                else
                {
                    Consonants++;
                }
            }
            Console.WriteLine(Vowels + "," + Consonants);
            Console.ReadLine();
        }
    }
}
