﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace words_using_loops
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            int Count = 0;
//            while (true)
//            {
//                var keyInfo = Console.ReadKey();
//                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
//                if (!char.IsLetter(letter))
//                {
//                    break;
//                }
//                Count++;
            
//            }
//            Console.WriteLine($"\nLetters: {Count}");
//            Console.ReadLine();
//        }
        
//    }
//}
