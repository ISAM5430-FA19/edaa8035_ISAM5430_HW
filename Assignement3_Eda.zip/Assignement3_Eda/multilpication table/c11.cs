﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace multilpication_table
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 9; i++)
            {
                for (int j = 1; j <= 9; j++)
                {
                    int n = i * j;
                    Console.Write(n+"\t");
                }
                Console.WriteLine();
            }
          
            Console.ReadLine();
        }
    }
}
