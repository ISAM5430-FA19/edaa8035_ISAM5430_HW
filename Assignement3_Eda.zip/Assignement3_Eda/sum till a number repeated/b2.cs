﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum_till_a_number_repeated
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int cur = 0;
            int prev = 0;

            Console.WriteLine("enter the number");
            while(true)
            {
                cur = int.Parse(Console.ReadLine());
                if(prev==cur)
                {
                    break;
                }
                else
                {

                    sum = prev + cur;
                }

            }
            Console.WriteLine(sum);
            Console.ReadLine();

        }

    }
}
