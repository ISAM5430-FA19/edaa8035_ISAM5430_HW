﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace star_pattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the count");
            int num = int.Parse(Console.ReadLine());
            for (int i = 0; i <= num; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
           // Console.WriteLine("\n");
            for (int i = num; i >= 0; i--)
            {
               for ( int j = i; j >= 0; j--)
                {
                    Console.Write("*");
                }
            Console.WriteLine();
        }
        //// Console.WriteLine("\n");
         for (int i = num; i >= 1; i--)
        {
           for (int j = num; j > i; j--)
                {
                    Console.Write(" ");
                }
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine(" ");
            }
            // //Console.WriteLine("\n");
            // for (int i = num; i >= 1; i--)
            // {
            //     for (int j = 1; j < i; j++)
            //     {
            //         Console.Write(" ");
            //     }
            //     for (int k = num; k >= i; k--)
            //     {
            //         Console.Write("*");
            //     }
            //     Console.WriteLine();
            // }
            // //Console.WriteLine("\n");
            Console.ReadLine();
        }
    }
}
