﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace principle_and_interest
{
    class c13
    {
        static void Main(string[] args)
        {
            decimal Principle = 1000;
            decimal amount = Principle;
            decimal interestRate=0.05m;
            for(int year=0;year<=10;year++)
            {
                amount = amount + Principle * interestRate;
            }




        }
    }
}
