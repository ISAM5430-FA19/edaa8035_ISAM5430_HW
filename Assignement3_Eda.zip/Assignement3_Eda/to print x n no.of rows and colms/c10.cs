﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace to_print_x_n_no.of_rows_and_colms
{
    class c10
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the value of the side:");
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    Console.Write("X");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
