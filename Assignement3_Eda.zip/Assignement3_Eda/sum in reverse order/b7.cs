﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum_in_reverse_order
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int carryover = 0;
            Console.WriteLine("enter 2 positive integers:");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
          while(a>0||b>0)
            {
                int A = a % 10;
                int B = b % 10;
                if (carryover != 0)
                {
                    sum = A + B + carryover;
                }
                else
                {
                    sum = A + B;
                }
                
                Console.WriteLine(sum); 
            }


        }
    }
}
