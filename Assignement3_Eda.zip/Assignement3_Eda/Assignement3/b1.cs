﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignement3
{
    class b1
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int bestScore = 0;
            float avg = 0;

            Console.WriteLine("enter the number of scores");
            int count = int.Parse(Console.ReadLine());
            for (int i = 0; i <= count; i++)
            {
                int num = int.Parse(Console.ReadLine());
                bestScore = int.MinValue;
                if (num > bestScore)
                {
                    bestScore = num;
                }
                if (num > 0 && num < 100)
                {
                    sum = sum + num;
                }
                else
                {
                    Console.WriteLine("invalid score");
                }

            }
            avg = sum / count;
            Console.WriteLine($"sum is{sum}");
            Console.WriteLine($"average is {avg}");
            Console.ReadLine();

        }
    }
}
    