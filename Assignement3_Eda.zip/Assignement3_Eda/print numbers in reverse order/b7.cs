﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace print_numbers_in_reverse_order
{
    class b7
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the numbers");
            int num = int.Parse(Console.ReadLine());
            while(num>1)
            {
                int num2 = num % 10;
                Console.WriteLine(num2);
                num = num / 10;

            }
            Console.ReadLine();
        }
    }
}
