﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sum_of_n_numbers_in_n.n_1by2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the number");
            int num = int.Parse(Console.ReadLine());
            for(int i=1;i<=num;i++)
            {
                for(int j=1;j<=i;j++)
                {
                    Console.Write(j);
                }
                Console.Write(",");
            }
            Console.WriteLine("\n sum is"+(num * num + 1) / 2);
            Console.ReadLine();
        }
    }
}
