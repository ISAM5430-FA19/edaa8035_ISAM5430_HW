﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sides_of_triangle
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("enter the sides of the traingle");
            int side1 = int.Parse(Console.ReadLine());
            int side2 = int.Parse(Console.ReadLine());
            int side3 = int.Parse(Console.ReadLine());
            while (true)
            {
                if (side1 <= 0 || side2 <= 0 || side3 <= 0)
                {
                    break;
                }
                else if (side1 + side2 > side3 || side2 + side3 > side1 || side1 + side3 > side2)
                {
                    Console.WriteLine("triangle is valid triangle");

                }
                else
                {
                    Console.WriteLine("invalid triangle");
                }
            }
            Console.ReadLine();
            
            }
        }
    }
}
