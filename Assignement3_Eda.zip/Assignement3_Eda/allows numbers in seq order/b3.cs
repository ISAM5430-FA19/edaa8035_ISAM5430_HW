﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace allows_numbers_in_seq_order
{
    class Program
    {
        static void Main(string[] args)
        {
            int maxvalue = int.MinValue;
            int number = 0;
            Console.WriteLine("enter the sequence");
            while (true)
            {
                number = int.Parse(Console.ReadLine());
                if(number>=maxvalue)
                {
                    maxvalue = number;
                }
                else
                {
                    break;
                }
            }
            Console.WriteLine($"max value is{maxvalue}");
            Console.ReadLine();

        }
    }
}
