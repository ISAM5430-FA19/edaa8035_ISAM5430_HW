﻿using System;

namespace ISAM5430.FA19.HW08
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
