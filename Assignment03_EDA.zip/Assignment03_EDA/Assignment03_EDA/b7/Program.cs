﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a positive integer:");
            int num = int.Parse(Console.ReadLine());
            while (num >=1)
            {
                int num2 = num % 10;
                Console.WriteLine(num2);
                num = num / 10;
            }
            Console.ReadLine();
        }
    }
}

