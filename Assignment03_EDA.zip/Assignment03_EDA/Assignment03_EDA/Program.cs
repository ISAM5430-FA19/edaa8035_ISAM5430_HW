﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment03_EDA
{
    class Program
    {
        static void Main(string[] args)
        {
            

                int sum = 0;
                int count = 0;
                int avg = 0;
                int maxscore = 0;
                int score = 0;
                string score2;

                Console.WriteLine("enter the scores");


                while (score <= 100 && score >= 0)
                {
                    if (score > maxscore)
                    {
                        maxscore = score;
                    }

                    sum = sum + score;
                    score2 = (Console.ReadLine());
                    if (string.IsNullOrEmpty(score2))
                        break;
                    score = int.Parse(score2);

                    count = count++;
                    if (count > 0)
                    {
                        avg = score / count;
                        Console.WriteLine(avg);
                    }

                    else
                    {
                        Console.WriteLine("error");
                    }


                }

            }
        }
    }

