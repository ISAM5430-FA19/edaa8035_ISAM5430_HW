﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b5
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = int.MinValue;
            int closestnumber = 0;
            int mindiff = int.MaxValue;
            Console.WriteLine("enter the integer:");
            int item = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the sequence of numbers:");
            while (num != item)
            {
                num = int.Parse(Console.ReadLine());

                if ((item - num) < mindiff)
                {
                    mindiff = item - num;
                    closestnumber = num;
                }
            }
            Console.WriteLine(closestnumber);
            Console.ReadLine();
        }
    }
}
