﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b3
{
    class Program
    {
        static void Main(string[] args)
        {
            int prev = int.MinValue;
            Console.WriteLine("enter the numbers in ascending order:");
            while(true)
            {
                int num = int.Parse(Console.ReadLine());
                if(num>prev)
                {
                    break;
                }
                else
                {
                    prev = num;
                }
                Console.WriteLine($"max number is:{prev}");
            }
            Console.ReadLine();

        }
    }
}
