﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c1
{
    class Program
    {
        static void Main(string[] args)
        {
            int rownum = 0;
            Console.WriteLine("enter the integer");
            int n = int.Parse(Console.ReadLine());
            while (rownum < n)
            {
                int column = 0;
                while (column < n)
                {
                    Console.Write('x');
                    column++;
                }
                Console.WriteLine();
                rownum++;
                //Console.ReadLine();
            }
        }
    }
}
