﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b4
{
    class Program
    {
        static void Main(string[] args)
        {
            int side1 = 0;
            int side2 = 0;
            int side3 = 0;
            Console.WriteLine("enter the values of the sides of triangle");
            while(true)
            {
                side1 = int.Parse(Console.ReadLine());
                side2 = int.Parse(Console.ReadLine());
                side3 = int.Parse(Console.ReadLine());
                if(side1<=0||side2<=0||side3<=0)
                {
                    break;
                }
                if(side1+side2<side3 && side2+side3<side1 && side1+side3<side1)
                {
                    Console.WriteLine("invalid");
                }
                else
                {
                    Console.WriteLine($"sides of triangle are{side1},{side2},{side3}");
                }
            }

        }
    }
}
