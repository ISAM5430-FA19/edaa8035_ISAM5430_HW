﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b8
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int carryover = 0;
            int rev = 0;
            int sum = 0;
            Console.WriteLine("enter positive integer,a");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("enter positive integer,b");
            int b = int.Parse(Console.ReadLine());

            while (a>0||b>0)

            {
                int c = a % 10;
                int d = b % 10;
                if (carryover != 0)
                    sum = c + d + carryover;
                else
                    sum = c + d;
                    carryover = sum % 10;
                rev = (rev * 10) + carryover;
                sum = sum / 10;

            }
            Console.WriteLine(rev);
            Console.ReadLine();

        }
    }
}
