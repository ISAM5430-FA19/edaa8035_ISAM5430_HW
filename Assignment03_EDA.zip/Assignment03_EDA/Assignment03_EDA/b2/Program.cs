﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace b2
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 0;
            int sum = 0;
            int prenumber = int.MinValue;
            Console.WriteLine("Enter the number ");
            
            while (true)
            {
                number = int.Parse(Console.ReadLine());
                if (prenumber == number)
                {
                    break;
                }
                prenumber = number;
                sum += number;
            }
            Console.WriteLine("The sum of the numbers entered is {0}", sum);
        }
    }
}
