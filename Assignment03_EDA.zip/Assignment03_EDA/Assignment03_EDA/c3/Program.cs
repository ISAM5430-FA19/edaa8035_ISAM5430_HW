﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int num = int.Parse(Console.ReadLine());
            int var = 0;
            for(int i =var;i<=num;i++)
            {
                if((var%1!=0)&&(var%var!=0))
                {
                    break;
                }
                else
                {
                    Console.WriteLine(var);
                }
            }
       
            Console.ReadLine();
        }
    }
}
